%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This is the demo code for 
%%%% "SIRF: Simultaneous Image Registration and Fusion in a unified
%%%% framework", by Chen Chen, Yeqing Li, Wei Liu and Junzhou Huang

%%%% and "Image Fusion with Local Spectral Consistency and Dynamic Gradient Sparsity"
%%%% by Chen Chen, Yeqing Li, Wei Liu and Junzhou Huang, CVPR 2014.

%%%% Contact: Chen Chen (chenchen.cn87@gmail.com) and Junzhou Huang
%%%% (jzhuang@uta.edu), Department of Computer Science and Engineering,
%%%% University of Texas at Arlington 

%%%% If you used our code, please cite our papers!


%%%% The dataset is downloaded from: http://glcf.umd.edu/data/ikonos/
%%%% GeoEye owns all IKONOS imagery. Access is provided here for education or research purposes only.
%%%% Users must credit GeoEye when using this imagery.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;close all;
addpath(genpath('.'));

load Sichuan;
ImageMS = 255*ImageMS/max(max(max(ImageMS)));
ImageP = 255*ImageP/max(max(max(ImageP)));

tp = ImageMS(:,:,3);
ImageMS(:,:,3) = ImageMS(:,:,1);
ImageMS(:,:,1) = tp;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T= size(ImageMS,3);
[m,n] = size(ImageP);
divK = 4; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  SIRF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf(1,'SIRF...\n');
lambda = 5;
[im,P]= SIRF(ImageMS,ImageP,divK,lambda, 150,3,1);

%%% use this one for hiding the registration process
% [im,P]= SIRF(ImageMS,ImageP,divK,lambda, 150,3,0);

% crop valid pixels
vv = 9;
ImageMS = ImageMS(floor(vv/4)+1:end-floor(vv/4),floor(vv/4)+1:end-floor(vv/4),:);
ImageP = ImageP(vv:end-vv+1,vv:end-vv+1,:);
im = im(vv:end-vv+1,vv:end-vv+1,:);
P = P(vv:end-vv+1,vv:end-vv+1,:);

close all;
figure;imshow(uint8((ImageP(:,:))),[]);title('Pan');
figure;imshow(uint8((P(:,:))),[]);title('Registered Pan by SIRF');

figure;imshow(uint8((ImageMS(:,:,1:3))),[]);title('Orginal RGB');
figure;imshow(uint8((im(:,:,1:3))),[]);title('Fusion by SIRF (RGB)');

figure;imshow(uint8((ImageMS(:,:,4))),[]);title('Orginal Nir');
figure;imshow(uint8((im(:,:,4))),[]);title('Fusion by SIRF (Nir)');

