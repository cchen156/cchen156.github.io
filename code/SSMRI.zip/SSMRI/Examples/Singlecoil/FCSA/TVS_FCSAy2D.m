function output = TVS_FCSAy2D(input,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% minimize alpha*TV(y) + beta*||Phi*y||_1 + 0.5*||Ry-b||_2^2
%%% Here y=Phi'*x  Phi:DWT,  Phi': IDWT
%%% Sep. 16, 2009, Created by Junzhou Huang
%%% Dec. 09, 2014, Revised by Chen Chen

%%% Junzhou Huang, Shaoting Zhang, Dimitris Metaxas, "Efficient MR Image Reconstruction for Compressed MR Imaging", 
%%% Medical Image Analysis, Volume 15, Issue 5, pp. 670-679, October 2011.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parsin.MAXITER=20; parsin.tv='iso'; %l=input.l; u=input.u;

n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;
y = Atb;
yr=zeros(size(y));
Lx=input.L; 
tnew=1;
alpha = input.alpha; beta = input.beta; 

for itr = 1:input.no    % total iter counter        

    told=tnew;
    yp=y;
    yg=yr-(A'*(A*yr)-Atb)/Lx;    
    if (itr==1)
        [ytv, P]=denoise_TV_One_complex(yg, 2*alpha/Lx,-inf,inf,[],parsin);
    else
        [ytv, P]=denoise_TV_One_complex(yg, 2*alpha/Lx,-inf,inf,P,parsin);
    end
    xg=Phi*yg;
    x = shrink1D(xg,zeros(n1,n2),2*beta/Lx);
    y=0.5*(ytv+Phi'*x); 

    tnew=(1+sqrt(1+4*told^2))/2; 
    yr=y+((told-1)/tnew)*(y-yp);    

    output.rmse(itr)=RMSE(y, input.f);

end

output.y=y; 


    function s1 = shrink1D(p,q,s)
        % shrink p toward q by up to s; p and q are vectors, s is scalar
        tmp = p - q; s1 = q + sign(tmp).*max(0,abs(tmp)-s);
    end
end