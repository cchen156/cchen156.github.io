%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is an example for compressive sensing MRI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Related papers:
% 
% Junzhou Huang, Shaoting Zhang, Dimitris Metaxas, "Efficient MR Image Reconstruction for Compressed MR Imaging", Medical Image Analysis, Volume 15, Issue 5, pp. 670-679, October 2011.
% 
% Chen Chen, and Junzhou Huang, "The Benefit of Tree Sparsity in Accelerated MRI", Medical Image Analysis, Volume 18, Issue 6, pp. 834�C842, 2014.
% 
% Chen Chen and Junzhou Huang, "Compressive Sensing MRI with Wavelet Tree Sparsity", the 26th Annual Conference on Neural Information Processing Systems (NIPS), Nevada, USA, 2012.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all;

load SL_complex;
im_Full = img(:,:,1);

alpha = 0.005; 
beta = 0.005; 

[m,n] = size(im_Full);
N = size(im_Full); 	% image Size
Itnlim = 150;   % Number of iterations

% Sampling Mask
d = 3.0;
pdf = genPDF([1,m], 6, 1/d, 2, 0.1, 0);
mask = fftshift(repmat(genSampling_symmetric(pdf,10,1),[m,1]));
mask = fftshift(mask);

%generate Fourier sampling operator
FT = p2DFT(mask, N, 1, 2);
data = FT*im_Full;

im_dc = FT'*(data);  % zero filling
im_dc = im_dc/max(abs(im_dc(:)));

%generate transform operator
DecLevel=6;
W = Wavelet('Daubechies',4,DecLevel);	% Wavelet transform
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FCSA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input.f=im_Full; 
input.n1=N(1);input.n2=N(2);
input.alpha=alpha;input.beta=beta;
input.Phi=W;
input.no=Itnlim; 
input.L=1;
input.b=data;
input.A=FT;

fprintf('calling the function FCSA.....\n');
out = TVS_FCSAy2D(input);

im_FCSA = out.y;
rmse_FCSA = out.rmse;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% WaTMRI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[IdxParent, IdxChildren, Ms] = WaveTreeStructure2D(m,DecLevel);
[G,Gmat,GmatX,groups]=GroupMatrics(IdxParent);
input.G=G;input.Gt=G';input.GtG=G'*G;
input.groups=groups;input.Gmat=Gmat;
input.alpha=alpha;input.beta=beta/15;lamda = 0.025;
input.lamda=lamda;
input.no=Itnlim; 
fprintf('calling the function WaTMRI.....\n');
out = WaTMRI2D(input);

im_WaTMRI = out.y;
rmse_WaTMRI = out.rmse;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;hold on;
plot(rmse_FCSA,'b');
plot(rmse_WaTMRI,'r');
legend('FCSA','WaTMRI');
xlabel('Iteration');
ylabel('RMSE');

figure;
subplot(2,3,1);imshow(abs(im_Full),[]);title('Groundtruth')
subplot(2,3,2);imshow(abs(mask),[]);title('mask')
subplot(2,3,3);imshow(abs(im_dc),[]);title('zere filling')
subplot(2,3,4);imshow(abs(im_FCSA),[]);title('FCSA')
subplot(2,3,5);imshow(abs(im_WaTMRI),[]);title('WaTMRI')

