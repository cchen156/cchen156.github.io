function output = WaTMRI2D(input,varargin)   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% minimize alpha*TV(y)+lambda*0.5*||G*Phi*y-z||_2^2+beta*(||z||_{2,1}+ ||Phi'*y||_1)
%%% + 0.5*||Ry-b||_2^2 
% input:
%          Phi: wavelet transform
%          Phi': inverse wavelet transform
%          R: partial Fourier transfrom
%          b: measurements
%          G:  matrix to transfer overlap groups to non-overlap
%             groups by extending x to z with G*x=z, where x,z are wavelet
%             coefficients        
%          groups: groups index of each element in z
%          beta,lambda,alpha: parameters

%%% Written by Chen Chen at University of Texas at Arlington
%%% Jan. 21, 2013,
%%% Revised Dec. 09. 2014

%%% Chen Chen, and Junzhou Huang, "The Benefit of Tree Sparsity in Accelerated MRI", Medical Image Analysis, Volume 18, Issue 6, pp. 834�C842, 2014.
%%%
%%% Chen Chen and Junzhou Huang, "Compressive Sensing MRI with Wavelet Tree Sparsity", the 26th Annual Conference on Neural Information Processing Systems (NIPS), 2012. 
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parsin.MAXITER=20; parsin.tv='iso';

n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;

Lx=input.L; tnew=1;
alpha = input.alpha;
beta = input.beta; 
lambda = input.lamda;
G=input.G;GtG=input.GtG; 
groups=input.groups; Gmat=input.Gmat;
y=Atb;
yr=y;
for itr = 1:input.no    % total iter counter        

    told=tnew;
    yp=y;
    
    if itr==1
        z = zeros(size(G,1),1);
    else
       z=shrink_group(G*xg(:),beta/lambda,0,groups,Gmat);
    end

    tp = Phi'*reshape(G'*z,n1,n2);
    tp = Phi'*reshape(GtG*reshape(Phi*yr,N,1),n1,n2)-tp;
    tp = (lambda/Lx)*tp;
    
    yg=yr-(A'*(A*yr)-Atb)/Lx-tp;
    
     if (itr==1)
        [yt, P]=denoise_TV_One_complex(yg, 2*alpha/Lx,-inf,inf,[],parsin); 
    else
        [yt, P]=denoise_TV_One_complex(yg, 2*alpha/Lx,-inf,inf,P,parsin);
    end
    
    xg=Phi*yg;
    x = shrink1D(xg,zeros(n1,n2), 2*beta/Lx);

    y=((Phi'* x)+yt)/2.0;


    tnew=(1+sqrt(1+4*told^2))/2; 
    yr=y+((told-1)/tnew)*(y-yp);     
 
    output.rmse(itr)=RMSE(y, input.f);
end

output.y=y; 

    function s1 = shrink1D(p,q,s)
        % shrink p toward q by up to s; p and q are vectors, s is scalar
        tmp = p - q; s1 = q + sign(tmp).*max(0,abs(tmp)-s);
    end
end