function output = TVS_FCSA_MT(b, RR, input)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% minimize alpha*JTV(X) + beta*||Phi*X||_{2,1} + 0.5*sum_{s}||R_{s}X(:,s)-b_{s}||_2^2
%%% Phi:DWT,  Phi': IDWT
%%% Jan. 16, 2012, Written by Junzhou Huang at UT Arlington
%%% Dec. 11, 2014, Revised by Chen Chen at UT Arlington
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parsin.MAXITER=20; parsin.tv='iso';

if iscell(b)
    T=length(b); 
else
    T = 1;
    RR = {RR};
    b = {b};
end


Lx=input.L; 
n1=input.n1; n2=input.n2; N=n1*n2;
alpha = input.alpha; beta = input.beta; 
Phi=input.Phi;

for t=1:T,
    Atb{t}=RR{t}'*b{t};
    y(:,:,t) = Atb{t}; 
end

yr=zeros(size(y));
tnew=1;

for itr = 1:input.no  % total iter counter        
    told=tnew;
    yp=y;
    for t=1:T
        temp=RR{t}'*(RR{t}*yr(:,:,t));
        temp=temp-Atb{t};
        yg(:,:,t)=yr(:,:,t)-temp/Lx; 
    end
    if (itr==1)
        [ytv, P1, P2]=denoise_TV_MT(yg, 2*alpha/Lx,-inf,inf,[],[], parsin);
    else
        [ytv, P1, P2]=denoise_TV_MT(yg, 2*alpha/Lx,-inf,inf,P1, P2,parsin);
    end

    
    for t=1:T,
        xg(:,:,t)=Phi*yg(:,:,t);
    end
    
    temp = max(0,1-(2*beta/Lx)./sqrt(sum(abs(xg).^2,3)));
    x=repmat(temp, [1,1, T]).*xg;
   
    for t=1:T,
        y(:,:,t)=0.5*(ytv(:,:,t)+Phi'*x(:,:,t));
    end    
    
    tnew=(1+sqrt(1+4*told^2))/2; 
    yr=y+((told-1)/tnew)*(y-yp);    

    output.rmse(itr)=RMSE(y, input.f);
    

end

output.y=y; 

end