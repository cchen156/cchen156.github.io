%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is an example for multicontrast MRI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Related papers:
%
% Junzhou Huang, Chen Chen and Leon Axel, ��Fast Multi-contrast MRI Reconstruction��, Magnetic Resonance Imaging, Volume 32, Issue 10, pp. 1344-1352, 2014.
%
% Junzhou Huang, Chen Chen, and Leon Axel, "Fast Multi-contrast MRI Reconstruction", the Annual International Conference on Medical Image Computing and Computer Assisted Intervention (MICCAI), Nice, France, October 2012.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all;


load SL_complex;
im_Full = img;

alpha = 1e-2; beta = 3.5e-2;  % regularization parameters
maxIter=200; 

[m n, T] = size(im_Full); N = m*n;

DecLevel=6;
W = Wavelet('Daubechies',4,DecLevel);	% Wavelet transform


d = 4;   %parameter to control sampling ratio 
[OMEGA] = RandMask_rect(double(m/d),double(n/d),m,n);
[mask] = RandMask_InverseTransfer(OMEGA,m,n);
figure;imshow(mask,[]);

for t=1:T
    [masks{t}] = mask;
end


%generate Fourier sampling operator
for t=1:T
A{t} = p2DFT(masks{t}, size(im_Full(:,:,1)), 1, 2);
b{t} = A{t}*im_Full(:,:,t);
im_dc(:,:,t) = A{t}'*b{t};
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% JTV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input.f=im_Full; input.n1=m;input.n2=n;
input.alpha=alpha; input.beta = beta;
input.L=1;
input.no=maxIter; %%%%  Change no for different iteration numbers
input.Phi=W;
fprintf('calling the function FCSA_MT.....\n');
out = TVS_FCSA_MT(b, A, input);
im_rec = out.y;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(out.rmse);
legend('FCSA\_MT');
xlabel('Iteration');
ylabel('RMSE');

figure; hold on;
subplot(2,3,1); imshow(abs(im_Full(:,:,1)),[]); title('Full');
subplot(2,3,4); imshow(abs(im_Full(:,:,2)),[]); title('Full');
subplot(2,3,2); imshow(abs(im_dc(:,:,1)),[]); title('Zero filling');
subplot(2,3,5); imshow(abs(im_dc(:,:,2)),[]); title('Zero filling');
subplot(2,3,3); imshow(abs(im_rec(:,:,1)),[]); title('FCSA\_MT');
subplot(2,3,6); imshow(abs(im_rec(:,:,2)),[]); title('FCSA\_MT');

