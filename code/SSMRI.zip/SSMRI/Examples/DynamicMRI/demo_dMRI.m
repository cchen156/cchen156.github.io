%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is an example for dynamic MRI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Related papers:
%
% Chen Chen, Yeqing Li, Leon Axel and Junzhou Huang, "Real Time Dynamic MRI with Dynamic Total Variation", the Annual International Conference on Medical Image Computing and Computer Assisted Intervention (MICCAI), 2014.
%
% Chen Chen, Yeqing Li, Leon Axel and Junzhou Huang, "Real Time Dynamic MRI by Exploiting Spatial and Temporal Sparsity with Dynamic Total Variation", submitted to IEEE Transactions on Image Processing.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all;

load perdata;
im_Full = perdata;
load Q192; % D in the paper

[m,n,seqlen] = size(im_Full);

N = [m,n];

% prepare sampling
OMEGA1=fftshift(MRImask(m,100));  % set 50--0.21
[mask1] = RandMask_InverseTransfer(OMEGA1,m,n);
k1 = length(find(OMEGA1~=0));
figure;imshow(mask1,[]); % for the first frame

OMEGA2=fftshift(MRImask(m,30));  % set 50--0.21
[mask2] = RandMask_InverseTransfer(OMEGA2,m,n);
k2 = length(find(OMEGA2~=0));
figure;imshow(mask2,[]); % for the rest frames

FT1 = p2DFT(mask1, N, 1, 2);  % partial FFT for the first frame
FT2 = p2DFT(mask2, N, 1, 2);  % partial FFT for the rest frames

% prepare measurements
for seq=1:seqlen
    x0 = im_Full(:,:,seq);
    if seq==1
        y2{seq}=FT1*x0;
    else
        y2{seq}=FT2*x0;
    end
end

% initialize
alpha = 0.001;
input.Q1 = Q1;input.Q2=Q2;
input.alpha = alpha; % regularization parameter
input.n1 =N(1);input.n2 = N(2);
input.no = 5; % number of iterations for outer loop, may need to change for different datasets
input.cgiter = 20;  % number of iterations for inner PCG loop, may need to change for different datasets

for seq=1:seqlen
    seq
    if seq==1
        AA =  A_operator(@(x) reshape(FT1*x,[m*n,1]), @(x) reshape(FT1'*x,[m*n,1]));
        ref = zeros(m,n,1);
        input.ratio = k1/(m*n);
    else
        input.ratio = k2/(m*n);
        AA =  A_operator(@(x) reshape(FT2*x,[m*n,1]), @(x) reshape(FT2'*x,[m*n,1]));
        ref = im_rec(:,:,1);
    end
    
    
    if seq==1
        input.f = im_Full(:,:,seq);
        input.A = AA;
        input.At = AA';
        input.b = y2{seq};
        out = FIRLS_TV(input);
        xout = out.y+ref(:);
        im_rec(:,:,seq) =  reshape(xout,[m,n]);
        rmse(seq) = RMSE(im_rec(:,:,seq),im_Full(:,:,seq));
    else
        input.f = im_Full(:,:,seq) - ref;
        input.A = AA;
        input.At = AA';
        input.b = y2{seq}-FT2*ref;
        input.x0 = ref(:);
        
        out = FIRLS_TV(input);
        xout = out.y+ref(:);
        im_rec(:,:,seq) =  reshape(xout,[m,n]);
        rmse(seq) = RMSE(im_rec(:,:,seq),im_Full(:,:,seq));
    end
end


showall(im_rec);
figure;plot(rmse);
legend('dTV reconstruction');
xlabel('Frame');
ylabel('RMSE');



