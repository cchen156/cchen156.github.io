function [Q1, Q2]=Grad_Mx(N)
Q1 = sparse(N,N);
n=sqrt(N);
for i=1:N
    if rem(i-1,n)==0
        Q1(i,i)=1;
        continue;
    end
    Q1(i,i)=1;
    Q1(i,i-1)=-1;
end

Q2 = sparse(N,N);
n=sqrt(N);
for i=1:N
    if i<=n
        Q2(i,i)=1;
        continue;
    end
    Q2(i,i)=1;
    Q2(i,i-n)=-1;
end
end


