function output = TVrec(input,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% minimize alpha*||x||_TV + 0.5*||Ax-b||_2^2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% l=input.l; u=input.u;
% if((l==-Inf)&&(u==Inf))
%     project=@(x)x;
% elseif (isfinite(l)&&(u==Inf))
%     project=@(x)(((l<x).*x)+(l*(x<=l)));
% elseif (isfinite(u)&&(l==-Inf))
%     project=@(x)(((x<u).*x)+((x>=u)*u));
% elseif ((isfinite(u)&&isfinite(l))&&(l<u))
%     project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
% else
%     error('lower and upper bound l,u should satisfy l<u');
% end


ratio =  input.ratio;
n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; b=input.b;
T = size(b,3);
At = input.At;

for t=1:T
    tp =At*b(:,t);
    Atb(:,t) = tp(:);
end

y= Atb;
alpha = input.alpha;

if isnumeric(A)
    AtA=At*A;
else
    AtA =  A_operator(@(x) At*(A*x), @(x) At*(A*x));
end
Q1 = input.Q1;
Q2 = input.Q2;
In = speye(N);
f0 = input.f;
t00 = cputime;
for itr = 1:input.no    % total iter counter

    
    % update weight
    yp=y;
    D1 = zeros(size(y(:,1)));
    D2 = D1;
    for t =1:T
        D1=D1 + (abs(Q1*y(:,t))+eps).^(2);
        D2=D2 + (abs(Q2*y(:,t))+eps).^(2);
    end
    D = (D1+D2).^(-0.5); %weight matrix
    
    P=ratio*In;
    tp=[(1:N)' (1:N)' D];
    dd=spconvert(tp);
    tp =  alpha*((Q1'*dd*Q1)+(Q2'*dd*Q2));
    P= P+ tp; %preconditioner
    %     S = AtA + tp;
    S = A_operator(@(x) AtA*x + tp*x, @(x) AtA*x + tp*x); %system matrix
    
    
    %construct LU
    d = diag(P);
    d1 = diag(P,1);
    d2 = diag(P,n1);
    d = diag(d);
    d1 = diag(d1,1);
    d2 = diag(d2,n1);
    U2 = d +d1 +d2;
    d1t = diag(P,-1);
    d2t = diag(P,-n1);
    ratios = 1./(diag(d));
    d1t = ratios(1:N-1).*d1t;
    d2t = ratios(1:N-n1).*d2t;
    L2 = In+diag(d1t,-1)+diag(d2t,-n1);
    %
    invp = @(x) FFP(L2,U2,x);
    invP =  A_operator(@(x) invp(x), @(x) invp(x));
    
    % PCG
    for t =1:T
        [y(:,t),k1,res(:,t),err(:,t)] =  PCG_operator(S,Atb(:,t),invP,input.cgiter,y(:,t),1e-15,1,f0);
    end
%     y = project(y);
    
    %     [f, f_prev]=get_f(A*y, y, alpha, b, f,n1,n2);
    output.err(:,itr) = sum(err,2);
    output.res(:,itr) = sum(res,2);
    
    output.rel(itr)=norm(y-yp, 'fro')/norm(yp, 'fro');
    output.snr(itr)=snr(y, input.f);
    output.xtime(itr)=cputime-t00;
    %     output.funv(iterno)=f;
    
end

output.res = mean(output.res,2);
output.err = mean(output.err,2);
output.y=y; %output.x=z;


function [f, f_prev]=get_f(Ay, y, alpha, b, f,n1,n2)
v1 = alpha*TV(y,n1,n2);
r3 = Ay - b; v3 = 0.5*(norm(r3).^2);
f_prev = f;
f = v1 + v3;
return

function TVx=TV(x,n1,n2)
% Total Variation norm of x, x is a n by n matrix
TV_eps = 0;
grad_x = [Grad1(x,n1,n2) Grad2(x,n1,n2)];
if 1
    pt_sqsum = sum(grad_x.*grad_x,2);
    if TV_eps == 0; TVx = sum(sqrt(pt_sqsum)); else TVx = sum(sqrt(pt_sqsum+TV_eps)); end
else
    TVx = norm(grad_x(:),1);
end
return
function p=Grad1(u,n1,n2)
% backward finite difference along dim 1
u = reshape(u,n1,n2);
p = [u(1,:);diff(u,1,1);];
p = p(:);
return

function q=Grad2(u,n1,n2)
% backward finite difference along dim 2
u = reshape(u,n1,n2);
q = [u(:,1) diff(u,1,2)];
q = q(:);
return
