SSMRI version 1.0 (Dec 11, 2014)
A toolbox for compressive sensing MRI with structured sparsity.

If you use our code, or any code modified from ours, please cite the related papers. 

Before running the codes, please first add all folders and subfolders into your MATLAB path.

The folder "SSMRI" contains all the functions implemented in this package. It has the following subfolders:
    
    Data contains sample datasets collected from the internet;
    Functions include the common functions used in MR image reconstruction;
    Examples contains the demo codes for different MRI applications, including single coil CSMRI, multicontrast MRI, dynamic MRI and parrallel MRI.

Parts of the data and codes are from the software SparseMRI by Michael Lustig. The codes have been revised to support complex-valued images, and the results may be slightly different from those in the papers.

If any problem, please contact Chen Chen (chenchen.cn87@gmail.com) and Junzhou Huang (jzhuang@uta.edu).