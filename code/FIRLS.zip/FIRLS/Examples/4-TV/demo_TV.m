%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of TV minimization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction." 
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all; clear all;

F = double(imread('3DMR_Chest.jpg'));
F=imresize(F, [256 256]);[m n] = size(F);

N = m*n;
f = F(:);
lambda = 0.01;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% prepare A and b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d = 4;   %%%% choose 3, 4,
[OMEGA] = RandMask_rect(double(m/d),double(n/d),m,n);
k = length(OMEGA);
[mask] = RandMask_InverseTransfer(OMEGA,m,n);
% figure;imshow(mask);
sigma = 0.01; noise = sigma*randn(2*k+1,1);

% partial FFT tranform
R = @(x) A_fhp_rect(x, OMEGA, m, n); 
RT = @(x) At_fhp_rect(x, OMEGA, m, n);
RR = A_operator(@(x) R(x), @(x) RT(x)); % A

b = R(f) + noise;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FIRLS_TV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FIRLS_TV.....\n');
input.tol = 1e-10;
input.no=50;
input.ratio = length(OMEGA)/N;
input.cgiter=20;
input.f=f;
input.n1=m;input.n2=n;
input.lambda=lambda;
input.l=-inf; input.u=inf;
input.b=b;input.A=RR;
[D1, D2] = discretefinitematrices(m,n);
input.D1=D1;
input.D2=D2;

input.At = RR';

out = FIRLS_TV(input);
im = out.y; 
im = reshape(im, [m, n]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lw=3;
figure; hold on;box on;
plot(out.snr, 'b-','linewidth', lw);
legend('FIRLS','Location','SouthEast');
xlabel('Iterations');
ylabel('SNR');
%
textobj = findobj('type', 'text');
set(textobj, 'fontsize', 12);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',14);
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',14);
figure; hold on;box on;
plot(out.xtime,out.snr, 'b-','linewidth', lw);
legend('FIRLS','Location','SouthEast');
xlabel('CPU Time(sec)');
ylabel('SNR');

textobj = findobj('type', 'text');
set(textobj, 'fontsize', 14);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',14);
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',14);

%
figure; hold on;
subplot(1,2,1); imshow(F, []); title('Original');
subplot(1,2,2) ;imshow(im, []); title('FIRLS');



