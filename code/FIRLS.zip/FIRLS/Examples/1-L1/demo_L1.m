%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of L1 norm minimization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction." 
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all;
n = 4000; k = 0.1*n; m = 0.4*n;                  % No. of rows (m), columns (n), and nonzeros (k)

A = randn(m,n);
A = A./repmat(sqrt(sum(A.^2,1)),[m,1]);

p  = randperm(n); p = p(1:k);              % Location of k nonzeros in x
x0 = zeros(n,1); x0(p) = randn(k,1);
b  = A*x0;

lambda = 1e-3;
maxiter = 100;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FIRLS_L1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FIRLS_L1.....\n');

input.lambda=lambda;
input.Phi=1;   % optional: can be wavelet, DCT, etc.

input.tol=1e-8;
input.l=-inf; input.u=inf;
input.f=x0;
input.A=A;
input.b=b;
input.no=maxiter;
input.ratio = 1;
input.cgiter=30;

out = FIRLS_L1(input);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
plot(out.snr);
xlabel('Iteration');
ylabel('SNR');

figure;
plot(out.rmse);
xlabel('Iteration');
ylabel('RMSE');

figure;
stem(x0);
hold on;
plot(out.y,'r*');
legend('True X','Reconstructed X');


