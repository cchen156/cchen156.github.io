%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of PCG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all;

F = double(imread('cameraman.pgm'));
F=mean(F,3);
F = F(20:83,90:153);

[m n] = size(F);
F=F/255;
f =F(:);

N=m*n;

tau = 1e-10;
lambda = 0.001;
%*******************************************************
M=round(N/2);
A = randn(M,N);
A = A./repmat(sqrt(sum(A.^2,1)),[M,1]);
%*******************************************************
x0 = f;
sigma = 0.01; noise = sigma*randn(M,1);
b = A*f + noise;
Phi = MakeHaarBases(N,1);
maxiter = 200;
maxcg = 20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% CG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input.n1=N;input.n2=1;
input.lambda=lambda;
input.Phi=Phi;
input.tol=1e-8;
input.l=-inf; input.u=inf;
input.f=f;
input.A=A;input.b=b;
input.cgiter=maxiter;
input.no=maxcg;
input.ratio = 1;

out = CG_IRLS(input);  % matlab wavelet
x1 = out.y;

res1 = out.res;
err1 = out.err;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Jacobi PCG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out = DPCG_IRLS(input);  % matlab wavelet
x2 = out.y;

res2 = out.res;
err2 = out.err;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Proposed PCG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out = PCG_IRLS(input);  % matlab wavelet
x3 = out.y;
res3 = out.res;
err3 = out.err;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lw=3;ms=1;fs=16;

figure;hold on;box on;
plot(err1(1:maxiter),'k--','linewidth', lw,'markersize', ms);
plot(err2(1:maxiter),'b-.','linewidth', lw,'markersize', ms);
plot(err3(1:maxiter),'r-','linewidth', lw,'markersize', ms);
legend('Standard CG','Jacobi PCG','the proposed PCG','Location','SouthEast');
xlabel('Iterations');
ylabel('Relative Error');
textobj = findobj('type', 'text');
set(textobj, 'fontsize', fs);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',fs);
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',fs);
