%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of L21 norm minimization
%%%% with non-overlapping groups
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction." 
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all;clear all;

load T2MRI; X=T2MRI(:,:, 90, 2:4);
m=256; n=m; maxIter=100; X=squeeze(X); X=double(X);
T=size(X, 3);
for t=1:T,
    temp=imresize(X(:,:,t), [m n]);
    F(:,:,t)=temp;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preparing the data and operators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m, n, T] = size(F); N = m*n; f=F(:); N=m*n;
d = 4; 
sigma = 0.01; 

wav = daubcqf(2);DecLevel=4;
W = @(x) midwt(x,wav);WT = @(x) mdwt(x,wav);
Phi= A_operator(@(x) WT(x), @(x) W(x));    % notice Phi=WT

for t=1:T,
    [OMEGA{t}] = RandMask_rect(double(m/d),double(n/d),m,n);
    k(t) = 2*length(OMEGA{t})+1;
    
    R{t} = @(x) A_fhp_rect(x, OMEGA{t}, m, n);
    RT{t} = @(x) At_fhp_rect(x, OMEGA{t}, m, n);
    RR{t} = A_operator(@(x) R{t}(x), @(x) RT{t}(x));
    
end

for t=1:T,
    start=1+sum(k(1:t-1)); stop=sum(k(1:t));
    sz(t,:)=[start, stop, N];
end

WW = @(x) [ Phi*(x(N*(1-1)+1:N)); Phi*(x(N*(2-1)+(1:N))); Phi*(x(N*(3-1)+(1:N)))];
WWT = @(x) [ Phi'*(x(N*(1-1)+1:N)); Phi'*(x(N*(2-1)+(1:N))); Phi'*(x(N*(3-1)+(1:N)))];
RF = @(x) [ RR{1}*(x(N*(1-1)+1:N)); RR{2}*(x(N*(2-1)+(1:N))); RR{3}*(x(N*(3-1)+(1:N)))];
RFT = @(x) [ RR{1}'*(x(sz(1,1):sz(1,2))); RR{2}'*(x(sz(2,1):sz(2,2))); RR{3}'*(x(sz(3,1):sz(3,2)))];

PHI= A_operator(@(x) WW(x), @(x) WWT(x));
PA= A_operator(@(x) RF(x), @(x) RFT(x));

b = PA*f;

k0=(k-1)/2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FIRLS_Joint
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FIRLS_Joint.....\n');
lambda = 3e-1;
input.f=f; 
input.Phi=Phi;

input.tol=1e-8; 

input.n1=N;input.n2=1;
input.lambda=lambda;
input.l=-inf; input.u=inf;
input.cgiter=20;
input.no=maxIter/input.cgiter;
input.ratio = k0/N; 
input.T = T;

input.Phi=PHI;
input.A = PA;
input.b = b;

out = FIRLS_MT(input);
im = out.y;
im = reshape(im,[m,n,T]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ls=3; ms=1; ts=16;

figure; hold on;
plot(out.xtime, out.snr, 'rd-', 'linewidth',ls, 'markersize', ms);
xlabel('CPU Time (sec)');ylabel('SNR');box on;
legend('FIRLS\_MT', 'Location','SouthEast');
textobj = findobj('type', 'text'); set(textobj, 'fontsize', ts);
h_xlabel = get(gca,'XLabel'); set(h_xlabel,'FontSize',ts);
h_xlabel = get(gca,'YLabel');set(h_xlabel,'FontSize',ts);

figure; hold on;
subplot(2,3,1); imshow(F(:,:,1), []); title('Original');
subplot(2,3,2); imshow(F(:,:,2), []); title('Original');
subplot(2,3,3); imshow(F(:,:,3), []); title('Original');
subplot(2,3,4) ;imshow(im(:,:,1), []); title('FIRLS');
subplot(2,3,5); imshow(im(:,:,2), []); title('FIRLS');
subplot(2,3,6); imshow(im(:,:,3), []); title('FIRLS');