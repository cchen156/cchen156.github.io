%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of JTV minimization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;clear all;

load T2MRI; X=T2MRI(:,:, 90, 2:4);
m=256; n=m; maxIter=2000; X=squeeze(X); X=double(X);
T=size(X, 3);
for t=1:T,
    temp=imresize(X(:,:,t), [m n]);
    F(:,:,t)=temp;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preparing the data and operators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m n, T] = size(F); N = m*n; f=F(:); pn=m*n;
d = 4; % change for 4 for 25% sampling

clear OMEGA A RR b bb;
wav = daubcqf(2);DecLevel=4;
W = @(x) midwt(x,wav);WT = @(x) mdwt(x,wav);
Phi= A_operator(@(x) WT(x), @(x) W(x));    % notice Phi=WT

for t=1:T,
    [OMEGA{t}] = RandMask_rect(double(m/d),double(n/d),m,n);
    k(t) = 2*length(OMEGA{t})+1;
end
for t=1:T,
    start=1+sum(k(1:t-1)); stop=sum(k(1:t));
    sz(t,:)=[start, stop, pn];
end


for t=1:T,
    f2=F(:,:, t); x0((t-1)*pn+1:t*pn,1)=WT(f2(:));
    f0((t-1)*pn+1:t*pn,1)=f2(:);
    R{t} = @(x) A_fhp_rect(x, OMEGA{t}, m, n);
    RT{t} = @(x) At_fhp_rect(x, OMEGA{t}, m, n);
    AO{t} = @(x) R{t}(W(x)); AOT{t} = @(x) WT(RT{t}(x));
    A{t} = A_operator(@(x) AO{t}(x), @(x) AOT{t}(x));
    sigma = 0.01; noise{t} = sigma*randn(k(t),1);
    start=sz(t,1); stop=sz(t,2);
    b(start:stop,1) = A{t}* x0((t-1)*pn+1:t*pn,1)+ noise{t};
end


for t=1:T,
    f2=F(:,:, t); ff0(:,t)=f2(:); xs(:,t)=WT(ff0(:,t));
    RR{t} = A_operator(@(x) R{t}(x), @(x) RT{t}(x));
    bb{t} = RR{t}*ff0(:,t) + noise{t};
end
k0=(k-1)/2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FIRLS_JTV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FIRLS_JTV.....\n');
lambda = 1e-1; 
input.cgiter=15;
input.f=f;  input.n1=m;input.n2=n;
input.lambda=lambda;
input.l=-inf; input.u=inf;
input.tol = 1e-8;
input.A = RR;input.At = RR';
input.b = bb;
input.no=20;
input.ratio = k0/(m*n);
[D1, D2] = discretefinitematrices(m,n);
input.D1=D1;
input.D2=D2;

out = FIRLS_JTV(input);  % matlab wavelet
im = out.y;
im = reshape(im,[m,n,T]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ls=3; ms=1; ts=16;

figure; hold on;
plot(out.xtime, out.snr, 'rd-', 'linewidth',ls, 'markersize', ms);
xlabel('CPU Time (sec)');ylabel('SNR');box on;
legend('FIRLS\_JTV', 'Location','SouthEast');
textobj = findobj('type', 'text'); set(textobj, 'fontsize', ts);
h_xlabel = get(gca,'XLabel'); set(h_xlabel,'FontSize',ts);
h_xlabel = get(gca,'YLabel');set(h_xlabel,'FontSize',ts);

figure; hold on;
subplot(2,3,1); imshow(F(:,:,1), []); title('Original');
subplot(2,3,2); imshow(F(:,:,2), []); title('Original');
subplot(2,3,3); imshow(F(:,:,3), []); title('Original');
subplot(2,3,4) ;imshow(im(:,:,1), []); title('FIRLS');
subplot(2,3,5); imshow(im(:,:,2), []); title('FIRLS');
subplot(2,3,6); imshow(im(:,:,3), []); title('FIRLS');