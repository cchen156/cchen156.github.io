%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This script is used to obtain the results of L21 norm minimization
%%%% with overlapping groups
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Related Papers %%%%

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction." 
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all; clear all; 

F = double(imread('MRI-Brain.jpg'));

[m n] = size(F); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2D wavelet transformation and sparse signal -- theta0 
DecLevel=4;
WaveletName='haar';
[C0, S0] = wavedec2(F, DecLevel, WaveletName);
[IdxParent, IdxChildren, Ms]=WaveRelation2D(C0, S0);
theta0=C0(:);

[G,Gmat,GmatX,groups]=GroupMatrics(IdxParent');
input.G=G;input.Gt=G';input.GtG=G'*G;
input.groups=groups;input.Gmat=Gmat;

maxiter = 10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preparing the data and operators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = m*n;   %%%% choose 3, 4, 
d=4; 
[OMEGA] = RandMask_rect(double(m/d),double(n/d),m,n);
% Number of projections
k = length(OMEGA);
[mask] = RandMask_InverseTransfer(OMEGA,m,n); 
% partial FFT tranform
R = @(x) A_fhp_rect(x, OMEGA, m, n);
RT = @(x) At_fhp_rect(x, OMEGA, m, n);
% define the function handles that compute 
% the products by W (inverse DWT) and W' (DWT)
WT = @(x) wavedec2(reshape(x,m,n),DecLevel,WaveletName)';
W = @(x) reshape(waverec2(x', S0, WaveletName),N,1); 

Phi = A_operator(@(x) WT(x), @(x) W(x));    % notice Phi=WT
RR = A_operator(@(x) R(x), @(x) RT(x));

f = F(:);
sigma = 0.01; noise = sigma*randn(2*k+1,1);
b = R(f) + noise;

lambda = 1e-3; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FIRLS_OG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FIRLS_OG.....\n');
input.n1=m;input.n2=n;
input.f=f;
input.A=RR;input.b=b;
input.Phi=Phi;

input.l=-inf; input.u=inf;
input.lambda=lambda;

input.tol = 1e-8;
input.cgiter=10;
input.no=maxiter;
input.ratio = k/N;
out = FIRLS_OG(input);  % matlab wavelet
im= out.y;
im=reshape(im, [m, n]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


titlename=num2str(1);  lw = 3;ms=2;fs=16;
h=figure; hold on;box on;
set(h,'name',titlename,'Numbertitle','off');
plot(out.snr, 'r-','linewidth', lw,'markersize', ms);
legend('FIRLS\_OG','Location','SouthEast');
xlabel('Iterations');
ylabel('SNR');
 textobj = findobj('type', 'text');
set(textobj, 'fontsize', fs);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',fs); 
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',fs); 

titlename=num2str(2); 
h=figure; hold on;box on;
set(h,'name',titlename,'Numbertitle','off');
plot(out.xtime ,out.snr, 'r-','linewidth', lw,'markersize', ms);
legend('FIRLS\_OG','Location','SouthEast');
xlabel('CPU Time (sec)');
ylabel('SNR');
 textobj = findobj('type', 'text');
set(textobj, 'fontsize', fs);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',fs); 
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',fs); 

 figure; hold on;
 subplot(1,2,1); imshow(F, []); title('Original');
 subplot(1,2,2) ;imshow(im, []); title('FIRLS\_OG');


