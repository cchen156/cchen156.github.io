%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The non-overlapping group sparsity version of FIRLS
%%% minimize 0.5*||Ay-b|| + lambda*||Phi*y||_{2,1}
%%% In this function, the y is a T*N*1 signal, y_i, y_{i+N},y_{i+2N}...
%%% form a group, i = 1, 2, ..., N. So there are total N groups.


% %%% Input:
% input.Phi: sparsifying transformation, can be wavelet transform or 1
% input.A: the sensing matrix
% input.b: the measurement
% input.lambda: regularization parameter
% input.cgiter: number of inner CG iterations
% input.f: the groudtruth. Used for calculating RMSE etc.
% input.ratio: the sampling ratio in compressive sensing problems
% input.tol: stopping tolerance
% input.l: the lower bound of x, may be 0 or -inf
% input.u; the upper bound of x, may be 1, 255 or inf
% input.n1, input.n2: the size of the image


% %%% Output
% output.y: the reconstructed image
% output.rel: the relative error
% output.snr: the SNR
% output.xtime: CPU time
% output.rmse: RMSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Contact
%%%% Chen Chen (chenchen.cn87@gmail.com)
%%%% Junzhou Huang (jzhuang@uta.edu) University of Texas at Arlington

%%%% Related Papers
%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function output = FIRLS_MT(input,varargin)

l=input.l; u=input.u;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
    project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end

n1=input.n1; n2=input.n2; N=n1*n2;
T = input.T;
A=input.A; Phi=input.Phi;b=input.b;

Atb = A'*b;
y = Atb;

lambda = input.lambda;

ratio = input.ratio;
ratio = repmat(ratio,[N,1]);
ratio = ratio(:);


iterno=0;
t00 = cputime;
for itr = 1:input.no  % total iter counter
    iterno=iterno+1;
    
    yp=y;
    
    GroupNorm = zeros(N,1);
    
    PhiY =Phi*y;
    for t=1:T
        GroupNorm = GroupNorm + PhiY((1:N)+(t-1)*N).^2;
    end    
    GroupNorm = GroupNorm +1e-8;
    
    W = GroupNorm.^(-0.5);
    W = repmat(W,[T 1]);     %compute current weights
    
    tp = lambda*W + ratio;
        
    invP =  @(x) Phi'*((Phi*x)./tp);
    InvP = A_operator(@(x) invP(x),@(x) invP(x));
    R =@(x) (A'*(A*x)+lambda*(Phi'*(W.*(Phi*x))));
    S =  A_operator(@(x) R(x), @(x) R(x));
    
    y =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,y);  %PCG iterations
    
    y=project(y);
   
    output.rel(iterno)=norm(y-yp, 'fro')/norm(yp, 'fro');
    output.snr(iterno)=snr(y, input.f);
    output.xtime(iterno)=cputime-t00;
    output.mses(iterno) = (norm(y-input.f)).^2/length(input.f);
    
    if(output.rel(end)<input.tol)
        display(['Done at iteration ' num2str(itr)]);
        break;
    end
end

output.y=y;

end