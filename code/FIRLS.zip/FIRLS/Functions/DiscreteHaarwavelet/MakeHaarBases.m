function W = MakeHaarBases(n,dim)
% usage W = MakeHaarBases(n,dim)
% inputs
% n = signal length per dimension
% dim = dimension
% output
% W  = wavelet matrix, columns correspond to locations in column major form

% 1D case
W = [ones(n,1)];
if dim==1
    
   levels = log2(n)-1; %total levels in the binary tree, topmost is 0
   for l = 0:levels
       numnodes = 2^l;              %number of nodes in that level
       piecelength = n/numnodes;    %length of the non zero part
       poslength = piecelength/2;   %length of each +1 and -1 piece
       vec = [ones(poslength,1); -1*ones(poslength,1)]; %the actual piece
       
       Z =zeros(n,numnodes); %initialize the submatrix for that scale
       
       currentind = 0;
       for k = 1:numnodes
           Z(currentind+1:currentind+piecelength,k) = vec;
           currentind = currentind+piecelength;
       end
       
       W = [W Z];
    
   end
   
end



colnorm = sqrt(sum(W.^2));
colnorm = repmat(colnorm,n,1);
W = W./colnorm;

end