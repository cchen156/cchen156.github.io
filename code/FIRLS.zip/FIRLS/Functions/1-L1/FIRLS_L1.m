%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The standard sparsity version of FIRLS
%%% minimize 0.5*||Ay-b|| + lambda*||Phi*y||_1

% %%% Input:
% input.Phi: sparsifying transformation, can be wavelet transform or 1
% input.A: the sensing matrix
% input.b: the measurement
% input.lambda: regularization parameter
% input.cgiter: number of inner CG iterations
% input.f: the groudtruth. Used for calculating RMSE etc.
% input.ratio: the sampling ratio in compressive sensing problems
% input.l: the lower bound of x, may be 0 or -inf
% input.u; the upper bound of x, may be 1, 255 or inf
% input.n1, input.n2: the size of the image
% input.tol: stopping tolerance

% %%% Output
% output.y: the reconstructed image
% output.rel: the relative error
% output.snr: the SNR
% output.xtime: CPU time
% output.rmse: RMSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Contact
%%%% Chen Chen (chenchen.cn87@gmail.com)
%%%% Junzhou Huang (jzhuang@uta.edu) University of Texas at Arlington

%%%% Related Papers
%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = FIRLS_L1(input,varargin)

l=input.l; u=input.u;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
    project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end

A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;

y= Atb;

lambda = input.lambda;
ratio = input.ratio;

if isnumeric(A)
    AtA=A'*A;
end

t00 = cputime;
for itr = 1:input.no  % total iter counter
    yp = y;
    
    W = (abs(Phi*y)+eps).^(-1);   %compute current weights
    
    if isnumeric(A)
        R =@(x) (AtA*x+lambda*(Phi'*(W.*(Phi*x))));
        S =  A_operator(@(x) R(x), @(x) R(x));
        invP =  @(x) Phi'*((Phi*(x))./(1+lambda*W));
        InvP = A_operator(@(x) invP(x),@(x) invP(x));
        y =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,y);  %PCG iterations
    else
        R =@(x) (A'*(A*x)+lambda*(Phi'*(W.*(Phi*x))));
        S =  A_operator(@(x) R(x), @(x) R(x));
        invP =  @(x) Phi'*((Phi*(x))./(ratio+lambda*W));
        InvP = A_operator(@(x) invP(x),@(x) invP(x));
        y =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,y);  %PCG iterations
    end
    y=project(y);
    
    output.rel(itr)=norm(y-yp, 'fro')/norm(yp, 'fro');
    output.snr(itr)=snr(y, input.f);
    output.xtime(itr)=cputime-t00;
    output.rmse(itr) = RMSE(y,input.f);
    
    if(output.rel(end)<input.tol)
        display(['Done at iteration ' num2str(itr)]);
        break;
    end
    
end
output.y=y;
end