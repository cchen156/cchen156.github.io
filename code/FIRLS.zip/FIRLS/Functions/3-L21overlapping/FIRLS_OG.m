%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The overlapping group sparsity version of FIRLS. It can be used for any group settings.
%%% minimize 0.5*||Ay-b|| + lambda*||G*Phi*y||_{2,1}
%%% 


% %%% Input:
% input.Phi: sparsifying transformation, can be wavelet transform or 1
% input.A: the sensing matrix
% input.b: the measurement
% input.lambda: regularization parameter
% input.cgiter: number of inner CG iterations
% input.f: the groudtruth. Used for calculating RMSE etc.
% input.ratio: the sampling ratio in compressive sensing problems
% input.tol: stopping tolerance
% input.l: the lower bound of x, may be 0 or -inf
% input.u; the upper bound of x, may be 1, 255 or inf
% input.n1, input.n2: the size of the image

% input.G: group index matrix; see the paper for more details
% input.Gmat: ||G*Phi*y||_{2,1} can be computed by sqrt((Gmat*G*Phi*y).^2)
% input.groups: indicating the group index of each entry

% %%% Output
% output.y: the reconstructed image
% output.rel: the relative error
% output.snr: the SNR
% output.xtime: CPU time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Contact
%%%% Chen Chen (chenchen.cn87@gmail.com)
%%%% Junzhou Huang (jzhuang@uta.edu) University of Texas at Arlington

%%%% Related Papers
%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function output = FIRLS_OG(input,varargin)

l=input.l; u=input.u;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
    project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end


n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;

y= Atb;

lambda = input.lambda;
G=input.G;
Gmat=input.Gmat;
groups=input.groups;

if isnumeric(A)
    AtA=A'*A;
end

[m,n]=size(G);
ratio = input.ratio;

t00 = cputime;
for itr = 1:input.no  % total iter counter
    yp=y;
    
    z = G*(Phi*y);
    groupnorm = Gmat*z.^2;
    Dy = groupnorm(groups);
    Dy = (Dy+eps).^(-0.5);    %compute current weights
    W = [(1:m)' (1:m)' Dy];
    W = spconvert(W);
    
    GWG = lambda*G'*W*G;
    GWG=diag(GWG);   % GDG is G'*W*G
    
    tp = GWG + ratio;
    invp =  @(x) Phi'*((Phi*x)./tp);
    InvP = A_operator(@(x) invp(x),@(x) invp(x));
    
    if isnumeric(A)
        R =@(x) (AtA*x+lambda*(Phi'*(G'*(Dy.*(G*(Phi*x))))));
    else
        R =@(x) (A'*(A*x)+lambda*(Phi'*(G'*(Dy.*(G*(Phi*x))))));
    end
    
    S =  A_operator(@(x) R(x), @(x) R(x));
    
    y =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,y);  %PCG iterations
    
    y=project(y);
    
    output.rel(itr)=norm(y-yp, 'fro')/norm(yp, 'fro');
    output.snr(itr)=snr(y, input.f);
    output.xtime(itr)=cputime-t00;
    
    if(output.rel(end)<input.tol)
        display(['Done at iteration ' num2str(itr)]);
        break;
    end
end

output.y=y;
end