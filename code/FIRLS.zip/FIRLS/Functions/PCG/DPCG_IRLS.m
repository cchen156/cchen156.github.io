function output = DPCG_IRLS(input,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l=input.l; u=input.u;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
    project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end

n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;
y= Atb;

lambda = input.lambda;


if isnumeric(A)
    AtA=A'*A;
end

for itr = 1:input.no  % total iter counter
    
    W = (abs(Phi*y)+eps).^(-1);
        
    R =@(x) (AtA*x+lambda*(Phi'*(W.*(Phi*x))));
    S =  A_operator(@(x) R(x), @(x) R(x));
    
    S_dense = AtA + lambda*Phi'*diag(W)*Phi;
    f0 = S_dense\Atb;
    
    invP = diag(S_dense);
    invP = invP.^(-1);
    invP = diag(invP);
    
    [y,k1,res,err] =  PCG_operator(S,Atb,invP,input.cgiter,y,1e-8,1,f0);
    
    y=project(y);
    
    output.err(:,itr) = err;
    output.res(:,itr)= res;
    
    
    
end
output.res = mean(output.res,2);
output.err = mean(output.err,2);
output.y=y;

end