function output = PCG_IRLS(input,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l=input.l; u=input.u;
if((l==-Inf)&&(u==Inf))
    project=@(x)x;
elseif (isfinite(l)&&(u==Inf))
    project=@(x)(((l<x).*x)+(l*(x<=l)));
elseif (isfinite(u)&&(l==-Inf))
    project=@(x)(((x<u).*x)+((x>=u)*u));
elseif ((isfinite(u)&&isfinite(l))&&(l<u))
    project=@(x)(((l<x)&(x<u)).*x)+((x>=u)*u)+(l*(x<=l));
else
    error('lower and upper bound l,u should satisfy l<u');
end

n1=input.n1; n2=input.n2; N=n1*n2;
A=input.A; Phi=input.Phi;b=input.b; Atb=A'*b;
y= Atb;

lambda = input.lambda;
ratio = input.ratio;

if isnumeric(A)
    AtA=A'*A;
end

for itr = 1:input.no  % total iter counter
    
    W = (abs(Phi*y)+eps).^(-1);
    
    S_dense = AtA+lambda*(Phi'*diag(W)*Phi);
    f0 = S_dense\Atb;
   
     if isnumeric(A)
        R =@(x) (AtA*x+lambda*(Phi'*(W.*(Phi*x))));
        S =  A_operator(@(x) R(x), @(x) R(x));
        invp =  @(x) Phi'*((Phi*(x))./(1+lambda*W));
        InvP = A_operator(@(x) invp(x),@(x) invp(x));
        [y,k1,res,err] =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,f0);
    else
        R =@(x) (A'*(A*x)+lambda*(Phi'*(W.*(Phi*x))));
        S =  A_operator(@(x) R(x), @(x) R(x));
        
        invp =  @(x) Phi'*((Phi*(x))./(ratio+lambda*Dy));        
        InvP = A_operator(@(x) invp(x),@(x) invp(x));        
        [y,k1,res,err] =  PCG_operator(S,Atb,InvP,input.cgiter,y,1e-8,1,f0);
    end
    y=project(y);
    
    output.err(:,itr) = err;
    output.res(:,itr)= res;
      
end
output.res = mean(output.res,2);
output.err = mean(output.err,2);
output.y=y;
end