FIRLS version 1.0 (Jan 05, 2014)

A toolbox for structured sparsity minimization.

If you use our code, or any code modified from ours, please cite the related papers. 

%%%% Chen Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Preconditioning for accelerated iteratively reweighted least squares in structured sparsity reconstruction."
%%%% In IEEE Conference on Computer Vision and Pattern Recognition (CVPR) , pp. 2713-2720. IEEE, 2014.

%%%% Chen, Chen, Junzhou Huang, Lei He, and Hongsheng Li. "Fast Iteratively Reweighted Least Squares Algorithms for Analysis-Based Sparsity Reconstruction." arXiv preprint arXiv:1411.5057 (2014).


Before running the codes, please first add all folders and subfolders into your MATLAB path.

The folder FIRLS contains all the functions implemented in this package. It has the following subfolders:
    
    Data contains sample datasets collected from the internet;
    Functions include the common functions used in different tasks;
    Examples contains the demo codes for different applications.

If any problem, please contact Chen Chen (chenchen.cn87@gmail.com) and Junzhou Huang (jzhuang@uta.edu).