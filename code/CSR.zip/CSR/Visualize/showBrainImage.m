function showBrainImage(im,min,max)

[m,n] = size(im);

% im = im(end:-1:1,:);

% pos = find(im>=0);
% neg = find(im<0);
% 
% themin = min(min(im));
% themax = max(max(im));
% 
% if abs(themin)>abs(themax)
%     im(pos) = im(pos)/abs(themin);
%     im(neg) = im(neg)/abs(themin);
% else
%     im(pos) = im(pos)/abs(themax);
%     im(neg) = im(neg)/abs(themax);
% end


box off;
imagesc(im,[min,max]);

set(gca,'xticklabel',[]);
set(gca,'yticklabel',[]);

set(gca,'ydir','normal');
h_xlabel = get(gca,'XLabel'); set(h_xlabel,'FontSize',14);
h_xlabel = get(gca,'YLabel');set(h_xlabel,'FontSize',14);
colorbar;
% axis([-10 10 -2.5 2.5]);

