function y = CSR(A,b,L,lambda,maxiter,m,n,tol)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% minimize lambda*||y||_2,1 + 0.5*||Ay-b||_2^2

% %%% Input:
% A: the Jacobi matrix
% b: the measurements
% L: the Lipschitz constant
% lambda: regularization parameter
% maxiter: number of iterations
% m,n: the size of the image
% tol: stopping tolerance

% %%% Output
% y: the reconstructed image

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Contact
%%%% Chen Chen (chenchen.cn87@gmail.com)
%%%% Junzhou Huang (jzhuang@uta.edu) University of Texas at Arlington

%%%% Related Papers
%%%%  Chen Chen, Fenghua Tian, Hanli Liu, and Junzhou Huang, "Diffuse optical tomography enhanced by clustered sparsity for functional brain imaging", 
%%%%  IEEE Transactions on Medical Imaging (TMI), Volume 33, Issue 12, pp. 2323-2331, 2014.   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Atb = A'*b;
y = Atb;yr=y;

if isnumeric(A)
    AtA=A'*A;
end

tnew = 1;
for itr = 1:maxiter  % total iter counter

    told=tnew;
    yp=y;

    if isnumeric(A)
        yg=yr-(AtA*yr-Atb)/L;
    else
        yg=yr-(A'*(A*yr)-Atb)/L;
    end
 
    yg = reshape(yg,[m n]);
    [y] = ConvnOG2(yg,m,n, 3,3, lambda/L, 20);
    y = y(:);

    tnew=(1+sqrt(1+4*told^2))/2;
    yr=y+((told-1)/tnew)*(y-yp);
    
    relativechange = norm(y-yp, 'fro')/norm(yp, 'fro');
    if(relativechange<tol)
        display(['Done at iteration ' num2str(itr)]);
        break;
    end
end

end