function [a, out] = ConvnOG2(y, m,n,K1, K2, lam, Nit)
% [a, cost] = ConvOG2(y, K1, K2, lam, Nit);
% Overlapping group shrinkage (2D)
% Minimizes the cost function with respect to a
%
% cost = 0.5*sum(sum(abs(y - a).^2)) + lam * sum(sqrt(conv(abs(a).^2, ones(K1,K2))));
%
% INPUT
%   y      : 2-D  noisy signal (2D array)
%   K1, K2 : size of group
%   lam    : regularization parameter
%   Nit    : number of iterations
%
% OUTPUT
%   a    : output (denoised signal)
%   cost : cost function history
% y = reshape(y,m,n);
a = y;                  % initialize
% h1 = ones(K1,1);        % for convolution 
% h2 = ones(K2,1);        % for convolution 
% h = [0,1,0;1,1,1;0,1,0];
h = [1,1,1;1,1,1;1,1,1];
epsl = 1e-8;


% f0 = reshape(f0,m,n);
% h  = ones(K1,K2);
% cost = zeros(1,Nit);
t0=cputime();
for it = 1:Nit

    r = sqrt(convn(abs(a).^2, h','same'));
    v=  1 + lam*convn(1./(r+epsl), h', 'same');
    a = y./v;    
%     out.snr(it)=snr(a,f0);
%     out.xtime(it)=cputime()-t0;
end

% a = a(:);