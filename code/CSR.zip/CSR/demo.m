%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a demo code for diffuse optical imaging with clustered sparstiy reconstruction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Contact
%%%% Chen Chen (chenchen.cn87@gmail.com)
%%%% Junzhou Huang (jzhuang@uta.edu) University of Texas at Arlington

%%%% Related Papers
%%%%  Chen Chen, Fenghua Tian, Hanli Liu, and Junzhou Huang, "Diffuse optical tomography enhanced by clustered sparsity for functional brain imaging", 
%%%%  IEEE Transactions on Medical Imaging (TMI), Volume 33, Issue 12, pp. 2323-2331, 2014.   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;close all;
addpath(genpath('.'));

load simudata
load Medium;


x0 = x(:);
b = A*x0;

m= 61; n =61;

iterall=1000;
sigma = 0.0004;
noise = sigma*randn(size(b));
SNR = snr(b,noise)
b = b + sigma*randn(size(b));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% L2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function L2.....\n');
beta =6.7739e-06;
x1 = inv(A'*A+ beta*eye(m*n))*A'*b;
im1 = reshape(x1,[m,n]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CSR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function L21.....\n');

d = eig(A'*A);
L = max(d);

beta = 1.0e-6;
x2 = CSR(A,b,L,beta,iterall,m,n,1e-8);

im2 = reshape(x2,[m,n]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
im0 = reshape(x0,[m,n]);

showImage(Medium,im0);title('Groudtruth');
showImage(Medium,im1);title('Reconstructed by L2');
showImage(Medium,im2);title('Reconstructed by CSR');



