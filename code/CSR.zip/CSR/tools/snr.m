function out = snr(signal,noise)

n = length(signal);

As = norm(signal)^2/n;
As = sqrt(As);

An = norm(noise)^2/n;
An = sqrt(An);


out = 20*log10(As/An);